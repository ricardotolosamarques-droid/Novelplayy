import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

void main() { WidgetsFlutterBinding.ensureInitialized(); runApp(const NovelPlay()); }

class Episode {
  final String id, title, url;
  final bool downloadAllowed;
  Episode(Map<String,dynamic> j): id=j['id'], title=j['title'], url=j['url'], downloadAllowed=j['downloadAllowed']==true;
}
class Drama {
  final String id,title,description,cover;
  final List<Episode> episodes;
  Drama(Map<String,dynamic> j): id=j['id'],title=j['title'],description=j['description'],cover=j['cover']??'',episodes=(j['episodes'] as List).map((e)=>Episode(e)).toList();
}
class NovelPlay extends StatelessWidget {
  const NovelPlay({super.key});
  @override Widget build(BuildContext context)=>MaterialApp(title:'NovelPlay',debugShowCheckedModeBanner:false,theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:Colors.deepPurple,brightness:Brightness.dark),useMaterial3:true),home:const Home());
}
class Home extends StatefulWidget {const Home({super.key}); @override State<Home> createState()=>_HomeState();}
class _HomeState extends State<Home> {
  List<Drama> dramas=[]; String query=''; int tab=0; Map<String,String> downloaded={};
  @override void initState(){super.initState();load();}
  Future<void> load() async {
    final raw=await rootBundle.loadString('assets/catalog.json');
    final prefs=await SharedPreferences.getInstance();
    final saved=prefs.getString('downloads');
    if(!mounted)return;
    setState((){dramas=(jsonDecode(raw) as List).map((e)=>Drama(e)).toList();downloaded=saved==null?{}:Map<String,String>.from(jsonDecode(saved));});
  }
  Future<void> saveDownloads() async {final prefs=await SharedPreferences.getInstance();await prefs.setString('downloads',jsonEncode(downloaded));}
  Future<void> download(Episode ep) async {
    if(!ep.downloadAllowed){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Download não autorizado para este episódio')));return;}
    if(Uri.tryParse(ep.url)?.scheme!='https' || !ep.url.toLowerCase().split('?').first.endsWith('.mp4')){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Download disponível somente para MP4 HTTPS autorizado')));return;
    }
    final dir=await getApplicationDocumentsDirectory();
    final file=p.join(dir.path,'${ep.id.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'),'_')}.mp4');
    final partial='$file.part';
    try {
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Baixando ${ep.title}...')));
      await Dio().download(ep.url,partial,options:Options(receiveTimeout:const Duration(minutes:15)));
      await File(partial).rename(file);
      if(!mounted)return;
      setState(()=>downloaded[ep.id]=file);await saveDownloads();
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Download concluído')));
    } catch(e){
      final f=File(partial);if(await f.exists())await f.delete();
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Falha no download: $e')));
    }
  }
  Future<void> remove(Episode ep) async {
    final path=downloaded[ep.id];if(path!=null){final f=File(path);if(await f.exists())await f.delete();}
    if(!mounted)return;setState(()=>downloaded.remove(ep.id));await saveDownloads();
  }
  @override Widget build(BuildContext context){
    final filtered=dramas.where((d)=>d.title.toLowerCase().contains(query.toLowerCase())).toList();
    final savedEpisodes=dramas.expand((d)=>d.episodes).where((e)=>downloaded.containsKey(e.id)).toList();
    return Scaffold(appBar:AppBar(title:const Text('NovelPlay'),actions:[IconButton(icon:const Icon(Icons.info_outline),onPressed:()=>showAboutDialog(context:context,applicationName:'NovelPlay',children:[const Text('Demo para vídeos próprios ou autorizados. O app não desbloqueia conteúdo premium.')]))]),body:tab==0?Column(children:[Padding(padding:const EdgeInsets.all(12),child:TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Buscar novelinhas',border:OutlineInputBorder()),onChanged:(v)=>setState(()=>query=v))),Expanded(child:ListView.builder(itemCount:filtered.length,itemBuilder:(context,i){final d=filtered[i];return Card(child:ListTile(leading:const Icon(Icons.movie,size:40),title:Text(d.title),subtitle:Text('${d.episodes.length} episódios • ${d.description}'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>DramaPage(drama:d,downloaded:downloaded,onDownload:download,onRemove:remove)))).then((_)=>setState((){}));}))]):ListView(children:savedEpisodes.map((e)=>ListTile(leading:const Icon(Icons.download_done),title:Text(e.title),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>PlayerPage(episode:e,localPath:downloaded[e.id]))),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>remove(e)))).toList()),bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),label:'Catálogo'),NavigationDestination(icon:Icon(Icons.download_outlined),label:'Downloads')]));
  }
}
class DramaPage extends StatelessWidget {
  final Drama drama;final Map<String,String> downloaded;final Future<void> Function(Episode) onDownload,onRemove;
  const DramaPage({super.key,required this.drama,required this.downloaded,required this.onDownload,required this.onRemove});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(drama.title)),body:ListView(children:[Padding(padding:const EdgeInsets.all(16),child:Text(drama.description)),...drama.episodes.asMap().entries.map((entry){final ep=entry.value;final saved=downloaded.containsKey(ep.id);return ListTile(leading:CircleAvatar(child:Text('${entry.key+1}')),title:Text(ep.title),subtitle:Text(saved?'Disponível offline':ep.downloadAllowed?'Streaming e download':'Somente streaming'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>PlayerPage(episode:ep,localPath:saved?downloaded[ep.id]:null))),trailing:IconButton(icon:Icon(saved?Icons.delete_outline:Icons.download_outlined),onPressed:()=>saved?onRemove(ep):onDownload(ep)));})]));
}
class PlayerPage extends StatefulWidget {final Episode episode;final String? localPath;const PlayerPage({super.key,required this.episode,this.localPath});@override State<PlayerPage> createState()=>_PlayerPageState();}
class _PlayerPageState extends State<PlayerPage> {
  VideoPlayerController? controller;String? error;
  @override void initState(){super.initState();initialize();}
  Future<void> initialize() async {
    try {
      final local=widget.localPath;
      final c=local!=null&&await File(local).exists()?VideoPlayerController.file(File(local)):VideoPlayerController.networkUrl(Uri.parse(widget.episode.url));
      controller=c;await c.initialize();await c.play();if(mounted)setState((){});
    }catch(e){if(mounted)setState(()=>error=e.toString());}
  }
  @override void dispose(){controller?.dispose();super.dispose();}
  @override Widget build(BuildContext context){final c=controller;return Scaffold(appBar:AppBar(title:Text(widget.episode.title)),body:Center(child:error!=null?Padding(padding:const EdgeInsets.all(20),child:Text('Não foi possível reproduzir: $error')):c==null||!c.value.isInitialized?const CircularProgressIndicator():Column(mainAxisSize:MainAxisSize.min,children:[AspectRatio(aspectRatio:c.value.aspectRatio,child:VideoPlayer(c)),const SizedBox(height:12),VideoProgressIndicator(c,allowScrubbing:true,padding:const EdgeInsets.all(12)),IconButton(icon:Icon(c.value.isPlaying?Icons.pause_circle:Icons.play_circle,size:48),onPressed:(){setState((){c.value.isPlaying?c.pause():c.play();});})])));
  }
}
