# NovelPlay — protótipo Flutter Android

Aplicativo de catálogo, streaming MP4 e download offline **somente de vídeos próprios ou licenciados**. Não inclui scraping de serviços, bypass de DRM, autenticação de terceiros ou desbloqueio de episódios premium.

## Compilar no Windows

1. Instale Flutter SDK, Android Studio e Android SDK. Confirme com `flutter doctor`.
2. Extraia esta pasta e abra um terminal dentro dela.
3. Execute `flutter create --platforms=android .` para gerar a pasta nativa Android (não incluída neste ZIP).
4. Execute `flutter pub get`.
5. Conecte um celular Android com depuração USB e execute `flutter run`.
6. Para gerar APK: `flutter build apk --release`. Arquivo em `build/app/outputs/flutter-apk/app-release.apk`.

## Conteúdo e direitos

Edite `assets/catalog.json` para adicionar séries e episódios que você tem permissão para distribuir/reproduzir. Cada episódio precisa de `id`, `title`, `url` HTTPS MP4 e `downloadAllowed` true/false. Não marque como true sem autorização de download. O projeto usa vídeos de demonstração públicos de amostra hospedados pelo Google. Verifique os direitos de qualquer conteúdo adicionado.

## Limitações da versão 1

- Streaming e downloads implementados para MP4. HLS/M3U8 poderá ser adicionado para streaming, mas download HLS não está implementado.
- Catálogo local JSON, sem backend ainda.
- Downloads armazenados no diretório privado do app; desinstalar o app pode apagá-los.
- Sem download em segundo plano nem barra de progresso; mantenha o app aberto durante downloads.
- Para catálogo remoto, autenticação, publicação na Play Store e proteção de links é necessária uma próxima etapa.
